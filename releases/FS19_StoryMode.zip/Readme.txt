This mod adds a story to the game.
It is for now designed to help getting started and guides the player through the first steps of the game.
The goal is also to provide mid and longterm motivation by giving the player goals to work to, in order to unlock new parts of the story.
Completing parts of the story also provides bonuses. For now only in the form of money.